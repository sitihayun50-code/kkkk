# Backend API
Tempat integrasi backend sungguhan:
- POST /orders
- GET /orders/:id
- PATCH /orders/:id/status
- POST /payment/create

Jangan menyimpan secret/API key di frontend atau repository publik.
