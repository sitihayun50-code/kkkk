window.STORE_CONFIG = {
  storeName: "NAZUAN STORE",
  whatsappNumber: "6280000000000",
  currency: "IDR",
  shippingFee: 10000
};
