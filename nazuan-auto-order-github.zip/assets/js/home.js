fetch("data/products.json").then(r=>r.json()).then(ps=>{
 featured.innerHTML=ps.slice(0,4).map(p=>`<article class="card product"><img src="${p.image}"><span>${p.category}</span><h3>${p.name}</h3><b>${money(p.price)}</b><button class="btn primary" onclick="addToCart('${p.id}')">Tambah</button></article>`).join("");
});
