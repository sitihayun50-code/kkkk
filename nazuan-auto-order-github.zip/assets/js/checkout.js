async function initCheckout(){
 const products=await fetch("../data/products.json").then(r=>r.json()), cart=getCart();
 let total=0;
 cartBox=document.getElementById("cart");
 if(!cart.length){cartBox.innerHTML="<p>Keranjang masih kosong.</p>";return}
 cartBox.innerHTML=cart.map(i=>{const p=products.find(x=>x.id===i.id);const sub=p.price*i.qty;total+=sub;return `<div class="cart-row"><b>${p.name}</b><span>${i.qty} × ${money(p.price)} = ${money(sub)}</span></div>`}).join("")+`<hr><h2>Total: ${money(total)}</h2>`;
 checkoutForm.onsubmit=e=>{
 e.preventDefault(); const fd=new FormData(checkoutForm);
 const order={id:"ORD-"+Date.now(),date:new Date().toISOString(),customer:Object.fromEntries(fd),items:cart,total};
 saveOrder(order);localStorage.removeItem(CART_KEY);
 result.innerHTML=`<div class="success">Pesanan <b>${order.id}</b> berhasil dibuat.</div>`;
 checkoutForm.reset(); updateCartCount();
 };
}
initCheckout();
