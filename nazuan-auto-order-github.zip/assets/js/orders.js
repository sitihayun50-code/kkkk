const orders=getOrders(); ordersEl=document.getElementById("orders");
ordersEl.innerHTML=orders.length?orders.map(o=>`<div class="card"><b>${o.id}</b><p>${new Date(o.date).toLocaleString("id-ID")}</p><p>${o.customer.name} — ${o.customer.phone}</p><strong>${money(o.total)}</strong></div>`).join(""):"<p>Belum ada pesanan.</p>";
