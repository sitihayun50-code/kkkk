const CART_KEY="nazuan_cart", ORDER_KEY="nazuan_orders";
const money=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
function getCart(){return JSON.parse(localStorage.getItem(CART_KEY)||"[]")}
function saveCart(c){localStorage.setItem(CART_KEY,JSON.stringify(c));updateCartCount()}
function addToCart(id){
 const c=getCart(), item=c.find(x=>x.id===id);
 if(item)item.qty++; else c.push({id,qty:1});
 saveCart(c); alert("Produk masuk keranjang.");
}
function updateCartCount(){const el=document.getElementById("cartCount");if(el)el.textContent=getCart().reduce((s,x)=>s+x.qty,0)}
function getOrders(){return JSON.parse(localStorage.getItem(ORDER_KEY)||"[]")}
function saveOrder(o){const a=getOrders();a.unshift(o);localStorage.setItem(ORDER_KEY,JSON.stringify(a))}
document.addEventListener("DOMContentLoaded",updateCartCount);
