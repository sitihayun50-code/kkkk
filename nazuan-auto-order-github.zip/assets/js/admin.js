const os=getOrders(); orderTotal.textContent=os.length; revenue.textContent=money(os.reduce((s,o)=>s+o.total,0));
adminOrders.innerHTML=os.map(o=>`<div class="card"><b>${o.id}</b><p>${o.customer.name} • ${o.customer.phone}</p><p>${o.customer.address}</p><strong>${money(o.total)}</strong></div>`).join("")||"<p>Belum ada order.</p>";
