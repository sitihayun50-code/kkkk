let allProducts=[];
async function loadProducts(){
 const r=await fetch("data/products.json"); allProducts=await r.json();
 const cats=[...new Set(allProducts.map(p=>p.category))];
 category.innerHTML='<option value="">Semua kategori</option>'+cats.map(c=>`<option>${c}</option>`).join("");
 render();
}
function render(){
 const q=search.value.toLowerCase(), cat=category.value;
 products.innerHTML=allProducts.filter(p=>(!q||p.name.toLowerCase().includes(q))&&(!cat||p.category===cat)).map(p=>card(p)).join("");
}
function card(p){return `<article class="card product"><img src="${p.image}" alt=""><span>${p.category}</span><h3>${p.name}</h3><b>${money(p.price)}</b><small>Stok: ${p.stock}</small><button class="btn primary" onclick="addToCart('${p.id}')">Tambah</button></article>`}
search.oninput=render; category.onchange=render; loadProducts();
